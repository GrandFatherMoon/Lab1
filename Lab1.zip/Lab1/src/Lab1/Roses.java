/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Lab1;

// ************************************************************
// File Name: Roses.java
// Author:Emre Batir
// Purpose:Prints out fun poem
// ************************************************************
public class Roses {
    
    public static void main(String[] args) {
        
        System.out.println("Roses are red");
        System.out.println("Violets are blue");
        System.out.println("Sugar is sweet");
        System.out.println("And so are you!");
        //Output in main
    }
    
}
