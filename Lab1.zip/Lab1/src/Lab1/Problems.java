/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Lab1;

// ********************************************
//	Problems.java
//
//	Provide lots of syntax errors for the user to correct.
//      Author: Emre Kaan Batir
//
//********************************************

public class Problems
{

public static void main (String[] args)
{

System.out.println ("!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
System.out.println ("This program used to have lots of problems,");
System.out.println ("but if it prints this, you fixed them all.");
System.out.println ("	*** Hurray! ***");
System.out.println ("!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");

}
}
