/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Lab1;

// ************************************************************
// File Name: Roses.java
// Author:Emre Batir
// Purpose:Prints counting to five in three languages
// ************************************************************
public class Count {
    public static void main(String[] args) {
        
        //SimHeEnglish //count to five
        
        System.out.println ("one two three four five"); 
        
        //French
        
        System.out.println ("un deux trois quatre cinq");
        
        //Spanish
        
        System.out.println ("uno dos tres cuatro cinco");
        
    }
}
