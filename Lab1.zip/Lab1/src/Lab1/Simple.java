/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Lab1;

// ********************************************
//	File name: Simple.java
//      Author: Emre Batir
//
//	Purpose: Print a simple message about Java.
//
// ********************************************

public class Simple
{

    public static void main (String[] args){

        System.out.println ("Java rocks!!");
    
    }

}
