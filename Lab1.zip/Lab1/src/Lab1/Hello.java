/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Lab1;

// ********************************************
//	Hello.java
//
//	Print a Hello, World message.
// ********************************************

public class Hello
{
// -----------------------------------
// main method -- prints the greeting
// -----------------------------------
    public static void main (String[] args){
    
        System.out.println ("Hello, World!");
}
}
